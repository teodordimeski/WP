package mk.ukim.finki.wp.kol2025g2.repository;

public interface SkiResortRepository {
}
